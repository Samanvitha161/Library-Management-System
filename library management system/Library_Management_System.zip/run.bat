@echo off
echo ============================================================
echo         LIBRARY MANAGEMENT SYSTEM (MINI PROJECT)
echo ============================================================
echo.
echo [1] Open Web Frontend (Clean white UI, no server required)
echo [2] Run C Console Program (library.exe)
echo [3] Compile C Program (library.c)
echo [4] Exit
echo.
set /p choice="Enter choice (1-4): "

if "%choice%"=="1" (
    echo Opening index.html in your default web browser...
    start "" index.html
    exit /b 0
)

if "%choice%"=="2" (
    if not exist "library.exe" (
        echo Compiling library.c first...
        call build.bat
    )
    cls
    library.exe
    exit /b 0
)

if "%choice%"=="3" (
    call build.bat
    pause
    exit /b 0
)

exit /b 0
